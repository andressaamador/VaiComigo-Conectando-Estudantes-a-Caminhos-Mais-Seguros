<?php
/**
 * Execução do Plano de Testes do VaiComigo (Seção 4.6 do TCC).
 *
 * Uso (com os contêineres em execução):
 *   docker compose exec php php tests/executar_testes.php
 *
 * O script cria usuários e caronas próprios (matrículas iniciadas por "TST"),
 * executa os casos TF01-TF12 e TI01-TI08 contra o banco real e remove os dados
 * criados ao final. O registro de cada execução (data, dados de entrada,
 * resultado obtido e situação) é salvo em tests/resultados/, no formato do
 * modelo de registro do plano de testes.
 *
 * TI01 e TI02 usam requisições HTTP ao próprio servidor (padrão: http://localhost/).
 * Para outro endereço, defina VAICOMIGO_URL (ex.: VAICOMIGO_URL=http://localhost:8080/).
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Execute este script pela linha de comando.');
}

require_once __DIR__ . '/../Classes/BD.php';
require_once __DIR__ . '/../Classes/Usuario.php';
require_once __DIR__ . '/../Classes/Carona.php';
require_once __DIR__ . '/../Classes/Solicitacao.php';
require_once __DIR__ . '/../Classes/Mensagem.php';
require_once __DIR__ . '/../Classes/Avaliacao.php';
require_once __DIR__ . '/../Classes/Notificacao.php';

date_default_timezone_set('America/Sao_Paulo');

const SENHA_TESTE = 'teste123';

class FalhaTeste extends Exception {}
class NaoExecutado extends Exception {}

$resultados = [];

/** Executa um caso de teste e registra o resultado */
function caso($id, $funcionalidade, $entrada, callable $fn) {
    global $resultados;
    $data = date('d/m/Y H:i:s');
    try {
        $obtido = $fn();
        $situacao = 'Aprovado';
    } catch (FalhaTeste $e) {
        $obtido = $e->getMessage();
        $situacao = 'Reprovado';
    } catch (NaoExecutado $e) {
        $obtido = $e->getMessage();
        $situacao = 'Não executado';
    } catch (Throwable $e) {
        $obtido = 'Erro inesperado: ' . $e->getMessage();
        $situacao = 'Reprovado';
    }
    $resultados[] = compact('id', 'funcionalidade', 'data', 'entrada', 'obtido', 'situacao');
    printf("[%s] %-4s %-30s %s\n", $situacao === 'Aprovado' ? ' OK ' : ($situacao === 'Reprovado' ? 'FAIL' : 'SKIP'), $id, $funcionalidade, $obtido);
}

function verificar($condicao, $mensagem) {
    if (!$condicao) {
        throw new FalhaTeste($mensagem);
    }
}

/** Executa $fn e devolve a mensagem da exceção esperada; falha se nada for lançado */
function esperarExcecao(callable $fn) {
    try {
        $fn();
    } catch (FalhaTeste $e) {
        throw $e;
    } catch (Throwable $e) {
        return $e->getMessage();
    }
    throw new FalhaTeste('A operação deveria ter sido rejeitada, mas foi aceita.');
}

// ---------------------------------------------------------------- fixtures
$conn = BD::getConnection();

function limparFixtures(PDO $conn) {
    // ON DELETE CASCADE remove caronas, solicitações, mensagens, avaliações e notificações dos usuários de teste
    $conn->exec("DELETE FROM usuarios WHERE matricula LIKE 'TST%'");
}

function criarUsuario(PDO $conn, $matricula, $nome, $ativo = 1) {
    $st = $conn->prepare("INSERT INTO usuarios (nome, email, senha, matricula, tipo_usuario, ativo) VALUES (?, ?, ?, ?, 'aluno', ?)");
    $st->execute([$nome, strtolower($matricula) . '@teste.local', password_hash(SENHA_TESTE, PASSWORD_DEFAULT), $matricula, $ativo]);
    return (int) $conn->lastInsertId();
}

function criarCarona($motoristaId, $vagas, $destino) {
    return (int) (new Carona())->inserir($motoristaId, 'IFTO Campus Colinas', $destino, date('Y-m-d', strtotime('+1 day')), '18:00', $vagas, 'Carona criada pelo roteiro de testes');
}

function linha(PDO $conn, $sql, array $params = []) {
    $st = $conn->prepare($sql);
    $st->execute($params);
    return $st->fetch(PDO::FETCH_ASSOC);
}

function valor(PDO $conn, $sql, array $params = []) {
    $st = $conn->prepare($sql);
    $st->execute($params);
    return $st->fetchColumn();
}

function idSolicitacao(PDO $conn, $caronaId, $passageiroId) {
    return (int) valor($conn, "SELECT id FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$caronaId, $passageiroId]);
}

limparFixtures($conn);
$M  = criarUsuario($conn, 'TST001', 'Motorista Teste');
$P1 = criarUsuario($conn, 'TST002', 'Passageiro Um');
$P2 = criarUsuario($conn, 'TST003', 'Passageiro Dois');
$P3 = criarUsuario($conn, 'TST004', 'Passageiro Tres');
$I  = criarUsuario($conn, 'TST005', 'Usuario Inativo', 0);
$O  = criarUsuario($conn, 'TST006', 'Usuario Externo');

$C1 = 0; $C2 = 0; $C3 = 0;

echo "VaiComigo - execução do plano de testes - " . date('d/m/Y H:i:s') . "\n\n";

// ---------------------------------------------------------------- testes funcionais
caso('TF01', 'Login válido', 'Matrícula TST001 (ativa) e senha correta', function () use ($M) {
    $u = Usuario::autenticarPorMatricula('TST001', SENHA_TESTE);
    verificar($u && (int) $u->id === $M, 'Credenciais válidas foram recusadas.');
    return 'Acesso concedido; perfil "' . $u->tipo_usuario . '".';
});

caso('TF02', 'Login inválido', 'TST001 com senha incorreta; matrícula inexistente TST999', function () {
    verificar(Usuario::autenticarPorMatricula('TST001', 'senha-errada') === false, 'Senha incorreta foi aceita.');
    verificar(Usuario::autenticarPorMatricula('TST999', SENHA_TESTE) === false, 'Matrícula inexistente foi aceita.');
    return 'Acesso negado nos dois casos.';
});

caso('TF03', 'Conta inativa', 'Matrícula TST005 (ativo = 0) e senha correta', function () {
    verificar(Usuario::autenticarPorMatricula('TST005', SENHA_TESTE) === false, 'Conta inativa conseguiu acessar.');
    return 'Acesso negado.';
});

caso('TF04', 'Oferta de carona', 'Origem IFTO Campus Colinas, destino Centro TST, amanhã 18:00, 3 vagas', function () use ($conn, $M, &$C1) {
    $C1 = criarCarona($M, 3, 'Centro TST');
    $c = linha($conn, "SELECT * FROM caronas WHERE id = ?", [$C1]);
    verificar($c && $c['status'] === 'ativa' && (int) $c['motorista_id'] === $M, 'Carona não registrada corretamente.');
    return "Carona #$C1 registrada como ATIVA e vinculada ao motorista.";
});

caso('TF05', 'Busca de carona', 'Busca por "IFTO" → "Centro TST" na data; busca por destino inexistente', function () use (&$C1) {
    $achadas = array_column(Carona::buscarDisponiveis('IFTO', 'Centro TST', date('Y-m-d', strtotime('+1 day'))), 'id');
    verificar(in_array($C1, array_map('intval', $achadas), true), 'A carona criada não apareceu na busca.');
    verificar(count(Carona::buscarDisponiveis('', 'Destino Inexistente TST')) === 0, 'A busca sem correspondência retornou resultados.');
    return 'Carona exibida com vagas livres; busca sem correspondência retornou lista vazia.';
});

caso('TF06', 'Solicitação de vaga', 'Passageiro TST002 solicita vaga na carona do TF04', function () use ($conn, $M, $P1, &$C1) {
    $antes = (int) valor($conn, "SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND tipo = 'solicitacao'", [$M]);
    Solicitacao::solicitar($C1, $P1);
    $s = linha($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C1, $P1]);
    $depois = (int) valor($conn, "SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND tipo = 'solicitacao'", [$M]);
    verificar($s && $s['status'] === 'pendente', 'Solicitação não ficou PENDENTE.');
    verificar($depois === $antes + 1, 'O motorista não foi notificado.');
    return 'Solicitação PENDENTE e notificação registrada para o motorista.';
});

caso('TF07', 'Solicitação duplicada', 'TST002 repete a solicitação; INSERT direto duplicado no banco', function () use ($conn, $P1, &$C1) {
    $msg = esperarExcecao(function () use ($C1, $P1) { Solicitacao::solicitar($C1, $P1); });
    $erroBanco = esperarExcecao(function () use ($conn, $C1, $P1) {
        $conn->prepare("INSERT INTO solicitacoes_carona (carona_id, passageiro_id) VALUES (?, ?)")->execute([$C1, $P1]);
    });
    verificar(strpos($erroBanco, '1062') !== false || stripos($erroBanco, 'Duplicate') !== false, 'O banco não aplicou a restrição UNIQUE.');
    return "Aplicação: \"$msg\"; banco: restrição UNIQUE (carona_id, passageiro_id) violada.";
});

caso('TF08', 'Aceite de solicitação', 'Motorista aceita a solicitação pendente de TST002', function () use ($conn, $M, $P1, &$C1) {
    Solicitacao::aceitar(idSolicitacao($conn, $C1, $P1), $M);
    $s = valor($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C1, $P1]);
    $ocupadas = (int) valor($conn, "SELECT vagas_ocupadas FROM caronas WHERE id = ?", [$C1]);
    $notif = (int) valor($conn, "SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND tipo = 'aceite'", [$P1]);
    verificar($s === 'aceita', 'A solicitação não mudou para ACEITA.');
    verificar($ocupadas === 1, "vagas_ocupadas deveria ser 1, mas é $ocupadas.");
    verificar($notif === 1, 'O passageiro não foi notificado do aceite.');
    return 'Status ACEITA, vagas_ocupadas = 1 e notificação ao passageiro.';
});

caso('TF09', 'Recusa e cancelamento', 'Motorista recusa TST003; TST004 solicita e cancela', function () use ($conn, $M, $P2, $P3, &$C1) {
    Solicitacao::solicitar($C1, $P2);
    Solicitacao::recusar(idSolicitacao($conn, $C1, $P2), $M);
    Solicitacao::solicitar($C1, $P3);
    Solicitacao::cancelar(idSolicitacao($conn, $C1, $P3), $P3);
    $s2 = valor($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C1, $P2]);
    $s3 = valor($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C1, $P3]);
    verificar($s2 === 'recusada', "Esperado RECUSADA, obtido $s2.");
    verificar($s3 === 'cancelada', "Esperado CANCELADA, obtido $s3.");
    return 'Status RECUSADA e CANCELADA, respectivamente.';
});

caso('TF10', 'Envio de mensagem', 'TST002 envia "Onde nos encontramos?" no chat da carona', function () use ($P1, &$C1) {
    Mensagem::enviar($C1, $P1, 'Onde nos encontramos?');
    $msgs = Mensagem::listar($C1, $P1);
    $ultima = end($msgs);
    verificar($ultima && $ultima['mensagem'] === 'Onde nos encontramos?' && (int) $ultima['usuario_id'] === $P1, 'Mensagem não registrada corretamente.');
    return 'Mensagem registrada com remetente, carona e data (' . $ultima['data_envio'] . ').';
});

caso('TF11', 'Avaliação válida', 'Tentativa antes da finalização; após finalizar, TST002 avalia o motorista com nota 4', function () use ($conn, $M, $P1, &$C1) {
    $antes = esperarExcecao(function () use ($C1, $P1, $M) { Avaliacao::avaliar($C1, $P1, $M, 4, 'cedo demais'); });
    Carona::finalizar($C1, $M);
    Avaliacao::avaliar($C1, $P1, $M, 4, 'Boa viagem');
    $media = (float) valor($conn, "SELECT avaliacao FROM usuarios WHERE id = ?", [$M]);
    verificar(abs($media - 4.0) < 0.001, "Média do motorista deveria ser 4,00, mas é $media.");
    return "Antes da finalização: \"$antes\". Depois: avaliação armazenada e média recalculada para 4,00.";
});

caso('TF12', 'Avaliação inválida', 'Nota 6; segunda avaliação do mesmo par; INSERT direto com nota 6', function () use ($conn, $M, $P1, &$C1) {
    $m1 = esperarExcecao(function () use ($C1, $P1, $M) { Avaliacao::avaliar($C1, $P1, $M, 6); });
    $m2 = esperarExcecao(function () use ($C1, $P1, $M) { Avaliacao::avaliar($C1, $P1, $M, 3); });
    $m3 = esperarExcecao(function () use ($conn, $C1, $P1, $M) {
        $conn->prepare("INSERT INTO avaliacoes (avaliador_id, avaliado_id, carona_id, nota) VALUES (?, ?, ?, 6)")->execute([$M, $P1, $C1]);
    });
    verificar(strpos($m3, '3819') !== false || stripos($m3, 'check') !== false, 'O banco não aplicou a restrição CHECK da nota.');
    return "Nota 6: \"$m1\"; repetida: \"$m2\"; banco: restrição CHECK violada.";
});

// ---------------------------------------------------------------- testes de integração (HTTP)
$base = rtrim(getenv('VAICOMIGO_URL') ?: 'http://localhost/', '/') . '/';

/** Requisição HTTP sem seguir redirecionamentos; devolve [status, headers, corpo] */
function http($metodo, $url, $cookie = '', $dados = null) {
    $headers = "User-Agent: VaiComigoTestes\r\n";
    if ($cookie !== '') {
        $headers .= "Cookie: $cookie\r\n";
    }
    $opcoes = ['method' => $metodo, 'header' => $headers, 'follow_location' => 0, 'ignore_errors' => true, 'timeout' => 5];
    if ($dados !== null) {
        $opcoes['header'] .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $opcoes['content'] = http_build_query($dados);
    }
    $corpo = @file_get_contents($url, false, stream_context_create(['http' => $opcoes]));
    $cab = function_exists('http_get_last_response_headers') ? (http_get_last_response_headers() ?? []) : ($http_response_header ?? []);
    if ($corpo === false && !$cab) {
        throw new NaoExecutado("Servidor indisponível em $url (defina VAICOMIGO_URL).");
    }
    preg_match('#HTTP/\S+\s+(\d{3})#', $cab[0] ?? '', $m);
    return [(int) ($m[1] ?? 0), $cab, (string) $corpo];
}

function cabecalho(array $cab, $nome) {
    foreach ($cab as $h) {
        if (stripos($h, $nome . ':') === 0) {
            return trim(substr($h, strlen($nome) + 1));
        }
    }
    return '';
}

$cookieAluno = '';

caso('TI01', 'Autenticação e sessão', "GET home.php sem sessão; POST login.php (TST002); GET home.php com sessão ($base)", function () use ($base, &$cookieAluno) {
    [$st1, $cab1] = http('GET', $base . 'home.php');
    verificar($st1 === 302 && stripos(cabecalho($cab1, 'Location'), 'login.php') !== false, "Sem sessão, esperado redirecionamento ao login (obtido HTTP $st1).");

    [$st2, $cab2] = http('POST', $base . 'login.php', '', ['matricula' => 'TST002', 'password' => SENHA_TESTE]);
    foreach ($cab2 as $h) {
        if (preg_match('/^Set-Cookie:\s*(PHPSESSID=[^;]+)/i', $h, $m)) {
            $cookieAluno = $m[1];
        }
    }
    verificar($st2 === 302 && $cookieAluno !== '', "Login válido não criou sessão (HTTP $st2).");

    [$st3, , $corpo3] = http('GET', $base . 'home.php', $cookieAluno);
    verificar($st3 === 200 && strpos($corpo3, 'Passageiro Um') !== false, "Com sessão, a página inicial não foi exibida (HTTP $st3).");
    return 'Sem sessão: redirecionado ao login; após login: sessão criada e página restrita acessível.';
});

caso('TI02', 'Controle de perfil', 'Estudante autenticado (TST002) acessa gestor.php', function () use ($base, &$cookieAluno) {
    if ($cookieAluno === '') {
        throw new NaoExecutado('Depende da sessão criada no TI01.');
    }
    [$st, $cab] = http('GET', $base . 'gestor.php', $cookieAluno);
    verificar($st === 302 && stripos(cabecalho($cab, 'Location'), 'login.php') !== false, "O estudante acessou o painel administrativo (HTTP $st).");
    return 'Acesso bloqueado e redirecionamento ao login.';
});

// ---------------------------------------------------------------- testes de integração (classes + banco)
caso('TI03', 'Oferta e busca', 'Motorista TST001 oferece carona para "Bairro TST"; busca pelo destino', function () use ($M, &$C2) {
    $C2 = criarCarona($M, 2, 'Bairro TST');
    $achada = null;
    foreach (Carona::buscarDisponiveis('', 'Bairro TST') as $c) {
        if ((int) $c['id'] === $C2) {
            $achada = $c;
        }
    }
    verificar($achada !== null, 'A carona não apareceu na busca.');
    verificar($achada['motorista_nome'] === 'Motorista Teste' && (int) $achada['vagas_livres'] === 2, 'Dados do motorista/vagas incorretos na visão.');
    return 'Carona exibida na busca com nome do motorista e 2 vagas livres (vw_caronas_completas).';
});

caso('TI04', 'Solicitação e notificação', 'TST002 solicita vaga na carona do TI03', function () use ($conn, $M, $P1, &$C2) {
    Solicitacao::solicitar($C2, $P1);
    $s = linha($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C2, $P1]);
    $n = linha($conn, "SELECT mensagem FROM notificacoes WHERE usuario_id = ? AND tipo = 'solicitacao' ORDER BY id DESC LIMIT 1", [$M]);
    verificar($s && $s['status'] === 'pendente', 'Solicitação não registrada.');
    verificar($n && strpos($n['mensagem'], 'Passageiro Um') !== false, 'Notificação ao motorista ausente ou sem o nome do passageiro.');
    return 'Registro em solicitacoes_carona e aviso ao motorista em notificacoes.';
});

caso('TI05', 'Aceites simultâneos', 'Carona com 1 vaga; TST002 e TST003 solicitam; bloqueio de linha e duas aceitações', function () use ($conn, $M, $P1, $P2, &$C3) {
    $C3 = criarCarona($M, 1, 'Vaga Unica TST');
    Solicitacao::solicitar($C3, $P1);
    Solicitacao::solicitar($C3, $P2);

    // (a) Duas conexões independentes: enquanto A mantém o FOR UPDATE, B não consegue bloquear a mesma carona
    $a = BD::novaConexao();
    $b = BD::novaConexao();
    $a->beginTransaction();
    $a->prepare("SELECT id FROM caronas WHERE id = ? FOR UPDATE")->execute([$C3]);
    $b->exec("SET SESSION innodb_lock_wait_timeout = 1");
    $b->beginTransaction();
    $bloqueado = false;
    try {
        $b->prepare("SELECT id FROM caronas WHERE id = ? FOR UPDATE")->execute([$C3]);
    } catch (PDOException $e) {
        $bloqueado = isset($e->errorInfo[1]) && (int) $e->errorInfo[1] === 1205;
    }
    if ($b->inTransaction()) { $b->rollBack(); }
    $a->rollBack();
    verificar($bloqueado, 'A segunda transação não aguardou o bloqueio da linha da carona.');

    // (b) Duas aceitações para a última vaga
    Solicitacao::aceitar(idSolicitacao($conn, $C3, $P1), $M);
    $msg = esperarExcecao(function () use ($conn, $C3, $P2, $M) { Solicitacao::aceitar(idSolicitacao($conn, $C3, $P2), $M); });
    $s2 = valor($conn, "SELECT status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ?", [$C3, $P2]);
    $c = linha($conn, "SELECT vagas_ocupadas, vagas_disponiveis FROM caronas WHERE id = ?", [$C3]);
    verificar($s2 === 'pendente', "A segunda solicitação deveria permanecer PENDENTE (obtido $s2).");
    verificar((int) $c['vagas_ocupadas'] === 1 && (int) $c['vagas_ocupadas'] <= (int) $c['vagas_disponiveis'], 'A capacidade da carona foi excedida.');
    return "Linha bloqueada durante a transação (erro 1205 na concorrente); 2ª aceitação rejeitada (\"$msg\"); vagas_ocupadas = 1/1.";
});

caso('TI06', 'Chat da carona', 'Motorista e TST002 trocam mensagens; TST006 (não participante) tenta ler e enviar', function () use ($M, $P1, $O, &$C1) {
    Mensagem::enviar($C1, $M, 'Na entrada principal do campus.');
    $msgs = Mensagem::listar($C1, $M);
    verificar(count($msgs) >= 2 && end($msgs)['mensagem'] === 'Na entrada principal do campus.', 'Mensagens fora de ordem ou ausentes.');
    $e1 = esperarExcecao(function () use ($C1, $O) { Mensagem::listar($C1, $O); });
    esperarExcecao(function () use ($C1, $O) { Mensagem::enviar($C1, $O, 'intruso'); });
    return 'Mensagens exibidas em ordem aos participantes; terceiro bloqueado ("' . $e1 . '").';
});

caso('TI07', 'Avaliação e reputação', 'Motorista avalia TST002 com nota 5 na carona finalizada', function () use ($conn, $M, $P1, &$C1) {
    Avaliacao::avaliar($C1, $M, $P1, 5, 'Pontual');
    $media = (float) valor($conn, "SELECT avaliacao FROM usuarios WHERE id = ?", [$P1]);
    $notif = (int) valor($conn, "SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND titulo = 'Nova avaliação'", [$P1]);
    verificar(abs($media - 5.0) < 0.001, "usuarios.avaliacao deveria ser 5,00, mas é $media.");
    verificar($notif === 1, 'O avaliado não foi notificado.');
    return 'Registro em avaliacoes e usuarios.avaliacao atualizado para 5,00.';
});

caso('TI08', 'Desativação de usuário', 'Administrador desativa a conta do motorista TST001', function () use ($conn, $M, &$C2) {
    $avaliacoesAntes = (int) valor($conn, "SELECT COUNT(*) FROM avaliacoes WHERE avaliado_id = ? OR avaliador_id = ?", [$M, $M]);
    (new Usuario())->alterarStatus($M, false);
    verificar(Usuario::autenticarPorMatricula('TST001', SENHA_TESTE) === false, 'Conta desativada conseguiu acessar.');
    $ids = array_map('intval', array_column(Carona::buscarDisponiveis('', 'Bairro TST'), 'id'));
    verificar(!in_array($C2, $ids, true), 'Carona do motorista desativado continua na busca.');
    $avaliacoesDepois = (int) valor($conn, "SELECT COUNT(*) FROM avaliacoes WHERE avaliado_id = ? OR avaliador_id = ?", [$M, $M]);
    verificar($avaliacoesDepois === $avaliacoesAntes && $avaliacoesAntes > 0, 'O histórico de avaliações não foi preservado.');
    return "Login bloqueado, carona oculta na busca e $avaliacoesDepois avaliação(ões) preservada(s).";
});

// ---------------------------------------------------------------- limpeza e relatório
limparFixtures($conn);

$aprovados = count(array_filter($resultados, function ($r) { return $r['situacao'] === 'Aprovado'; }));
$reprovados = count(array_filter($resultados, function ($r) { return $r['situacao'] === 'Reprovado'; }));
$naoExec = count($resultados) - $aprovados - $reprovados;

printf("\nTotal: %d casos | Aprovados: %d | Reprovados: %d | Não executados: %d\n", count($resultados), $aprovados, $reprovados, $naoExec);

$dir = __DIR__ . '/resultados';
if (!is_dir($dir)) {
    mkdir($dir, 0775, true);
}
$arquivo = $dir . '/execucao-' . date('Ymd-His') . '.md';
$md = "# Registro de execução do plano de testes – VaiComigo\n\n";
$md .= "Executado em " . date('d/m/Y H:i:s') . " | PHP " . PHP_VERSION . " | MySQL " . $conn->query('SELECT VERSION()')->fetchColumn() . "\n\n";
$md .= "| Caso | Funcionalidade | Data | Dados de entrada | Resultado obtido | Situação |\n|---|---|---|---|---|---|\n";
foreach ($resultados as $r) {
    $md .= '| ' . implode(' | ', array_map(function ($v) { return str_replace(['|', "\n"], ['\|', ' '], (string) $v); },
        [$r['id'], $r['funcionalidade'], $r['data'], $r['entrada'], $r['obtido'], $r['situacao']])) . " |\n";
}
$md .= "\nTotal: " . count($resultados) . " casos | Aprovados: $aprovados | Reprovados: $reprovados | Não executados: $naoExec\n";
file_put_contents($arquivo, $md);
echo "Registro salvo em $arquivo\n";

exit($reprovados > 0 ? 1 : 0);
