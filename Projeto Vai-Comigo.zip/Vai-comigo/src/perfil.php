<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/BD.php';
require_once __DIR__ . '/Classes/Carona.php';
require_once __DIR__ . '/Classes/Solicitacao.php';

$uid = getIdUsuario();
$conn = BD::getConnection();

// RF03: nome, matrícula e e-mail vêm da base institucional; o estudante complementa apenas o telefone
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    $telefone = preg_replace('/\D+/', '', (string) ($_POST['telefone'] ?? ''));
    if ($telefone !== '' && (strlen($telefone) < 10 || strlen($telefone) > 11)) {
        flash('danger', 'Informe o telefone com DDD (10 ou 11 dígitos).');
    } else {
        $st = $conn->prepare("UPDATE usuarios SET telefone = ? WHERE id = ?");
        $st->execute([$telefone !== '' ? $telefone : null, $uid]);
        $_SESSION['usuario_logado']['telefone'] = $telefone;
        flash('success', 'Telefone atualizado.');
    }
    header('Location: perfil.php');
    exit;
}

$st = $conn->prepare("SELECT nome, email, matricula, telefone, avaliacao, foto_perfil FROM usuarios WHERE id = ?");
$st->execute([$uid]);
$perfil = $st->fetch(PDO::FETCH_ASSOC);

$totalOferecidas = count(Carona::listarDoMotorista($uid));
$totalAceitas = count(array_filter(Solicitacao::listarPorPassageiro($uid), function ($s) {
    return $s['status'] === 'aceita';
}));

$page_title = 'Perfil';
$page_css = 'perfil.css';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="container-perfil">
        <div class="cabecalho-perfil">
            <div class="avatar-perfil">
                <?php if (!empty($perfil['foto_perfil']) && $perfil['foto_perfil'] !== 'Array'): ?>
                    <img src="imagens/<?php echo e($perfil['foto_perfil']); ?>" alt="Foto de perfil" class="rounded-circle" style="width:100%;height:100%;object-fit:cover;">
                <?php else: ?>
                    <i class="fas fa-user"></i>
                <?php endif; ?>
            </div>
            <h2><?php echo e($perfil['nome']); ?></h2>
            <p class="mb-0">Matrícula: <?php echo e($perfil['matricula']); ?></p>
            <div class="estatisticas-perfil">
                <div class="estatistica">
                    <div class="numero-estatistica"><?php echo (int) $totalOferecidas; ?></div>
                    <div class="rotulo-estatistica">Caronas oferecidas</div>
                </div>
                <div class="estatistica">
                    <div class="numero-estatistica"><?php echo (int) $totalAceitas; ?></div>
                    <div class="rotulo-estatistica">Caronas como passageiro</div>
                </div>
                <div class="estatistica">
                    <div class="numero-estatistica"><?php echo (float) $perfil['avaliacao'] > 0 ? number_format((float) $perfil['avaliacao'], 1, ',', '') : '–'; ?></div>
                    <div class="rotulo-estatistica">Avaliação</div>
                </div>
            </div>
        </div>

        <div class="conteudo-perfil">
            <div class="secao-perfil">
                <h3 class="titulo-secao"><i class="fas fa-user"></i> Informações pessoais</h3>
                <p class="text-muted small">
                    Nome, matrícula e e-mail são obtidos da base de dados institucional e não podem ser alterados aqui.
                </p>
                <form method="POST">
                    <?php echo csrfCampo(); ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nome completo</label>
                            <input type="text" class="form-control" value="<?php echo e($perfil['nome']); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">E-mail</label>
                            <input type="email" class="form-control" value="<?php echo e($perfil['email']); ?>" readonly>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label" for="telefone">Telefone (opcional)</label>
                            <input type="tel" id="telefone" name="telefone" class="form-control" placeholder="(63) 99999-9999"
                                   value="<?php echo e($perfil['telefone']); ?>">
                            <div class="form-text">Visível apenas aos participantes das caronas aceitas.</div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Salvar telefone</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
