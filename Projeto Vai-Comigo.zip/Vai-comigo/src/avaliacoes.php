<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Avaliacao.php';

$uid = getIdUsuario();

// Registrar avaliação (RF11, RN07)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    try {
        Avaliacao::avaliar(
            (int) ($_POST['carona_id'] ?? 0),
            $uid,
            (int) ($_POST['avaliado_id'] ?? 0),
            $_POST['nota'] ?? '',
            $_POST['comentario'] ?? ''
        );
        flash('success', 'Avaliação registrada. Obrigado!');
    } catch (Exception $e) {
        flash('danger', $e->getMessage());
    }
    header('Location: avaliacoes.php');
    exit;
}

$pendentes = Avaliacao::pendentes($uid);
$recebidas = Avaliacao::recebidas($uid);
$enviadas = Avaliacao::enviadas($uid);

function estrelasTexto($nota) {
    $nota = (int) $nota;
    return str_repeat('★', $nota) . str_repeat('☆', 5 - $nota);
}

$page_title = 'Avaliações';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="painel">
        <h2 class="text-center mb-2"><i class="fas fa-star text-warning me-2"></i>Avaliações</h2>
        <p class="text-center text-muted small">As avaliações ficam disponíveis após a finalização da carona.</p>

        <h3 class="titulo-secao"><i class="fas fa-pen me-2"></i>Para avaliar</h3>
        <?php if (!$pendentes): ?>
            <p class="text-muted">Nenhuma avaliação pendente.</p>
        <?php endif; ?>
        <?php foreach ($pendentes as $i => $p): ?>
            <div class="cartao-carona">
                <div class="trecho"><?php echo e($p['avaliado_nome']); ?>
                    <span class="badge bg-light text-dark"><?php echo e($p['papel'] === 'motorista' ? 'Motorista' : 'Passageiro'); ?></span>
                </div>
                <div class="detalhe mb-2">
                    <?php echo e($p['origem']); ?> → <?php echo e($p['destino']); ?> · <?php echo e(dataHoraBR($p['data_viagem'], $p['hora_viagem'])); ?>
                </div>
                <form method="POST">
                    <?php echo csrfCampo(); ?>
                    <input type="hidden" name="carona_id" value="<?php echo (int) $p['carona_id']; ?>">
                    <input type="hidden" name="avaliado_id" value="<?php echo (int) $p['avaliado_id']; ?>">
                    <div class="estrelas mb-2" role="radiogroup" aria-label="Nota">
                        <?php for ($n = 5; $n >= 1; $n--): ?>
                            <?php $idEstrela = 'nota-' . $i . '-' . $n; ?>
                            <input type="radio" id="<?php echo $idEstrela; ?>" name="nota" value="<?php echo $n; ?>" required>
                            <label for="<?php echo $idEstrela; ?>" title="<?php echo $n; ?> estrela(s)"><i class="fas fa-star"></i></label>
                        <?php endfor; ?>
                    </div>
                    <textarea name="comentario" class="form-control mb-2" rows="2" maxlength="1000" placeholder="Comentário (opcional)"></textarea>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-paper-plane me-1"></i>Enviar avaliação</button>
                </form>
            </div>
        <?php endforeach; ?>

        <h3 class="titulo-secao"><i class="fas fa-inbox me-2"></i>Recebidas</h3>
        <?php if (!$recebidas): ?>
            <p class="text-muted">Você ainda não recebeu avaliações.</p>
        <?php endif; ?>
        <?php foreach ($recebidas as $a): ?>
            <div class="cartao-carona">
                <span class="text-warning"><?php echo estrelasTexto($a['nota']); ?></span>
                <strong class="ms-2"><?php echo e($a['avaliador_nome']); ?></strong>
                <div class="detalhe"><?php echo e($a['origem']); ?> → <?php echo e($a['destino']); ?> · <?php echo e(formatDateBR($a['data_viagem'])); ?></div>
                <?php if (!empty($a['comentario'])): ?><div class="mt-1"><?php echo e($a['comentario']); ?></div><?php endif; ?>
            </div>
        <?php endforeach; ?>

        <h3 class="titulo-secao"><i class="fas fa-paper-plane me-2"></i>Enviadas</h3>
        <?php if (!$enviadas): ?>
            <p class="text-muted">Você ainda não enviou avaliações.</p>
        <?php endif; ?>
        <?php foreach ($enviadas as $a): ?>
            <div class="cartao-carona">
                <span class="text-warning"><?php echo estrelasTexto($a['nota']); ?></span>
                <strong class="ms-2"><?php echo e($a['avaliado_nome']); ?></strong>
                <div class="detalhe"><?php echo e($a['origem']); ?> → <?php echo e($a['destino']); ?> · <?php echo e(formatDateBR($a['data_viagem'])); ?></div>
                <?php if (!empty($a['comentario'])): ?><div class="mt-1"><?php echo e($a['comentario']); ?></div><?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
