<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Carona.php';
require_once __DIR__ . '/Classes/Solicitacao.php';

$uid = getIdUsuario();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    $id = (int) ($_POST['id'] ?? 0);
    try {
        switch ($_POST['acao'] ?? '') {
            case 'aceitar':
                Solicitacao::aceitar($id, $uid);
                flash('success', 'Solicitação aceita. O passageiro foi notificado.');
                break;
            case 'recusar':
                Solicitacao::recusar($id, $uid);
                flash('info', 'Solicitação recusada.');
                break;
            case 'cancelar_solicitacao':
                Solicitacao::cancelar($id, $uid);
                flash('info', 'Sua solicitação foi cancelada.');
                break;
            case 'finalizar':
                Carona::finalizar($id, $uid);
                flash('success', 'Carona finalizada. Agora você pode avaliar os passageiros.');
                break;
            case 'cancelar_carona':
                Carona::cancelar($id, $uid);
                flash('info', 'Carona cancelada. Os passageiros foram notificados.');
                break;
            default:
                flash('danger', 'Ação inválida.');
        }
    } catch (Exception $e) {
        flash('danger', $e->getMessage());
    }
    header('Location: minhas-caronas.php');
    exit;
}

$oferecidas = Carona::listarDoMotorista($uid);
$solicitadas = Solicitacao::listarPorPassageiro($uid);

/** Botão de ação em formulário POST com CSRF */
function botaoAcao($acao, $id, $rotulo, $classe, $icone, $confirmar = '') {
    $onsubmit = $confirmar !== '' ? ' onsubmit="return confirm(\'' . e($confirmar) . '\');"' : '';
    return '<form method="POST" class="d-inline"' . $onsubmit . '>' . csrfCampo()
        . '<input type="hidden" name="acao" value="' . e($acao) . '">'
        . '<input type="hidden" name="id" value="' . (int) $id . '">'
        . '<button type="submit" class="btn btn-sm ' . e($classe) . '"><i class="fas ' . e($icone) . ' me-1"></i>' . e($rotulo) . '</button>'
        . '</form>';
}

$page_title = 'Minhas Caronas';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="painel">
        <h2 class="text-center mb-2">Minhas Caronas</h2>

        <!-- Caronas oferecidas (motorista) -->
        <h3 class="titulo-secao"><i class="fas fa-car me-2"></i>Que eu ofereço</h3>
        <?php if (!$oferecidas): ?>
            <p class="text-muted">Você ainda não ofereceu caronas. <a href="cadastro.php">Oferecer carona</a></p>
        <?php endif; ?>

        <?php foreach ($oferecidas as $c): ?>
            <?php $solicitacoes = Solicitacao::listarPorCarona($c['id']); ?>
            <div class="cartao-carona">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="trecho"><?php echo e($c['origem']); ?> <i class="fas fa-arrow-right mx-1"></i> <?php echo e($c['destino']); ?></div>
                        <div class="detalhe">
                            <i class="fas fa-calendar me-1"></i><?php echo e(dataHoraBR($c['data_viagem'], $c['hora_viagem'])); ?>
                            · <?php echo (int) $c['vagas_ocupadas']; ?>/<?php echo (int) $c['vagas_disponiveis']; ?> vagas ocupadas
                        </div>
                    </div>
                    <?php echo badgeStatus($c['status']); ?>
                </div>

                <div class="lista-solicitacoes">
                    <?php if (!$solicitacoes): ?>
                        <span class="text-muted small">Nenhuma solicitação recebida.</span>
                    <?php endif; ?>
                    <?php foreach ($solicitacoes as $s): ?>
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                            <div>
                                <strong><?php echo e($s['passageiro_nome']); ?></strong> <?php echo badgeStatus($s['status']); ?>
                                <?php if ($s['status'] === 'aceita'): ?>
                                    <div class="detalhe small">
                                        <i class="fas fa-envelope me-1"></i><?php echo e($s['passageiro_email']); ?>
                                        <?php if (!empty($s['passageiro_telefone'])): ?>
                                            · <i class="fas fa-phone me-1"></i><?php echo e($s['passageiro_telefone']); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if ($s['status'] === 'pendente' && $c['status'] === 'ativa'): ?>
                                <div class="d-flex gap-1">
                                    <?php echo botaoAcao('aceitar', $s['id'], 'Aceitar', 'btn-success', 'fa-check'); ?>
                                    <?php echo botaoAcao('recusar', $s['id'], 'Recusar', 'btn-outline-danger', 'fa-times'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="d-flex gap-2 flex-wrap mt-2">
                    <a href="chat.php?carona=<?php echo (int) $c['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-comments me-1"></i>Chat</a>
                    <?php if ($c['status'] === 'ativa'): ?>
                        <?php echo botaoAcao('finalizar', $c['id'], 'Finalizar', 'btn-outline-success', 'fa-flag-checkered', 'Confirmar que a viagem foi realizada?'); ?>
                        <?php echo botaoAcao('cancelar_carona', $c['id'], 'Cancelar carona', 'btn-outline-secondary', 'fa-ban', 'Cancelar esta carona? Os passageiros serão avisados.'); ?>
                    <?php elseif ($c['status'] === 'finalizada'): ?>
                        <a href="avaliacoes.php" class="btn btn-sm btn-outline-warning"><i class="fas fa-star me-1"></i>Avaliar</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <!-- Caronas solicitadas (passageiro) -->
        <h3 class="titulo-secao"><i class="fas fa-user me-2"></i>Que eu solicitei</h3>
        <?php if (!$solicitadas): ?>
            <p class="text-muted">Você ainda não solicitou caronas. <a href="busca.php">Buscar carona</a></p>
        <?php endif; ?>

        <?php foreach ($solicitadas as $s): ?>
            <div class="cartao-carona">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="trecho"><?php echo e($s['origem']); ?> <i class="fas fa-arrow-right mx-1"></i> <?php echo e($s['destino']); ?></div>
                        <div class="detalhe">
                            <i class="fas fa-calendar me-1"></i><?php echo e(dataHoraBR($s['data_viagem'], $s['hora_viagem'])); ?>
                            · Motorista: <?php echo e($s['motorista_nome']); ?>
                        </div>
                        <?php if ($s['status'] === 'aceita'): ?>
                            <div class="detalhe small">
                                <i class="fas fa-envelope me-1"></i><?php echo e($s['motorista_email']); ?>
                                <?php if (!empty($s['motorista_telefone'])): ?>
                                    · <i class="fas fa-phone me-1"></i><?php echo e($s['motorista_telefone']); ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="text-end">
                        <div>Solicitação: <?php echo badgeStatus($s['status']); ?></div>
                        <div class="small mt-1">Carona: <?php echo badgeStatus($s['carona_status']); ?></div>
                    </div>
                </div>
                <div class="d-flex gap-2 flex-wrap mt-2">
                    <?php if ($s['status'] === 'aceita'): ?>
                        <a href="chat.php?carona=<?php echo (int) $s['carona_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-comments me-1"></i>Chat</a>
                    <?php endif; ?>
                    <?php if (($s['status'] === 'pendente' || $s['status'] === 'aceita') && $s['carona_status'] === 'ativa'): ?>
                        <?php echo botaoAcao('cancelar_solicitacao', $s['id'], 'Cancelar solicitação', 'btn-outline-danger', 'fa-times', 'Cancelar sua solicitação?'); ?>
                    <?php endif; ?>
                    <?php if ($s['status'] === 'aceita' && $s['carona_status'] === 'finalizada'): ?>
                        <a href="avaliacoes.php" class="btn btn-sm btn-outline-warning"><i class="fas fa-star me-1"></i>Avaliar</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
