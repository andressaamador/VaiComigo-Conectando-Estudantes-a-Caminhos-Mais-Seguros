<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Carona.php';
require_once __DIR__ . '/Classes/Solicitacao.php';

$uid = getIdUsuario();

$minhasAtivas = count(array_filter(Carona::listarDoMotorista($uid), function ($c) {
    return $c['status'] === 'ativa';
}));
$pendentesRecebidas = 0;
foreach (Carona::listarDoMotorista($uid) as $c) {
    if ($c['status'] === 'ativa') {
        foreach (Solicitacao::listarPorCarona($c['id']) as $s) {
            if ($s['status'] === 'pendente') {
                $pendentesRecebidas++;
            }
        }
    }
}
$disponiveis = array_values(array_filter(Carona::buscarDisponiveis(), function ($c) use ($uid) {
    return (int) $c['motorista_id'] !== $uid;
}));
$recentes = array_slice($disponiveis, 0, 4);

$page_title = 'Página Inicial';
$page_css = 'home.css';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="container-home">
        <div class="cabecalho-boas-vindas">
            <div class="avatar-usuario"><i class="fas fa-user"></i></div>
            <h2><?php echo e(getNomeUsuario()); ?></h2>
            <p class="mb-3"><?php echo isAdmin() ? 'Administrador' : 'Estudante'; ?></p>

            <div class="container-estatisticas">
                <div class="item-estatistica">
                    <div class="numero-estatistica"><?php echo (int) $minhasAtivas; ?></div>
                    <div class="rotulo-estatistica">Minhas caronas ativas</div>
                </div>
                <div class="item-estatistica">
                    <div class="numero-estatistica"><?php echo (int) $pendentesRecebidas; ?></div>
                    <div class="rotulo-estatistica">Solicitações pendentes</div>
                </div>
                <div class="item-estatistica">
                    <div class="numero-estatistica"><?php echo count($disponiveis); ?></div>
                    <div class="rotulo-estatistica">Caronas disponíveis</div>
                </div>
            </div>

            <div class="botoes-acao">
                <a href="cadastro.php" class="btn btn-light btn-lg"><i class="fas fa-plus-circle me-2"></i>Oferecer Carona</a>
                <a href="busca.php" class="btn btn-outline-light btn-lg"><i class="fas fa-search me-2"></i>Buscar Carona</a>
            </div>
        </div>

        <div class="secao-conteudo">
            <h3 class="titulo-secao"><i class="fas fa-clock"></i> Próximas caronas disponíveis</h3>
            <?php if (!$recentes): ?>
                <p class="text-muted">Nenhuma carona disponível no momento.</p>
            <?php endif; ?>
            <div class="caronas-recentes">
                <?php foreach ($recentes as $c): ?>
                    <div class="cartao-carona">
                        <div class="d-flex justify-content-between">
                            <strong><i class="fas fa-user-circle"></i> <?php echo e($c['motorista_nome']); ?></strong>
                            <span class="badge bg-success"><i class="fas fa-users me-1"></i><?php echo (int) $c['vagas_livres']; ?> vaga(s)</span>
                        </div>
                        <div class="mt-2 detalhe">
                            <div><i class="fas fa-map-marker-alt"></i> De: <?php echo e($c['origem']); ?></div>
                            <div><i class="fas fa-location-dot"></i> Para: <?php echo e($c['destino']); ?></div>
                            <div><i class="fas fa-calendar"></i> <?php echo e(dataHoraBR($c['data_viagem'], $c['hora_viagem'])); ?></div>
                        </div>
                        <a href="busca.php?<?php echo e(http_build_query(['origem' => $c['origem'], 'destino' => $c['destino'], 'data' => $c['data_viagem']])); ?>"
                           class="btn btn-outline-primary btn-sm mt-2"><i class="fas fa-info-circle me-1"></i>Ver e solicitar</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
