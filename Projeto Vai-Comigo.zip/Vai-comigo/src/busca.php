<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Carona.php';
require_once __DIR__ . '/Classes/Solicitacao.php';

$uid = getIdUsuario();

// Solicitar vaga (RF06)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    try {
        Solicitacao::solicitar((int) ($_POST['carona_id'] ?? 0), $uid);
        flash('success', 'Solicitação enviada! Você será notificado quando o motorista responder.');
    } catch (Exception $e) {
        flash('danger', $e->getMessage());
    }
    // Volta para a mesma busca (padrão Post/Redirect/Get)
    $volta = 'busca.php?' . http_build_query([
        'origem' => $_POST['origem'] ?? '',
        'destino' => $_POST['destino'] ?? '',
        'data' => $_POST['data'] ?? '',
    ]);
    header('Location: ' . $volta);
    exit;
}

$origem = trim((string) ($_GET['origem'] ?? ''));
$destino = trim((string) ($_GET['destino'] ?? ''));
$data = trim((string) ($_GET['data'] ?? ''));
if ($data !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
    $data = '';
}

$caronas = Carona::buscarDisponiveis($origem, $destino, $data);

// Situação das solicitações do usuário, para não oferecer "Solicitar" de novo
$minhas = [];
foreach (Solicitacao::listarPorPassageiro($uid) as $s) {
    $minhas[(int) $s['carona_id']] = $s['status'];
}

$page_title = 'Buscar Carona';
$page_css = 'busca.css';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="painel">
        <h2 class="text-center mb-4">Buscar Carona</h2>

        <form method="GET" class="row g-2 mb-2">
            <div class="col-md-4">
                <label class="rotulo-formulario" for="origem"><i class="fas fa-map-marker-alt me-2"></i>Partida</label>
                <input type="text" id="origem" name="origem" class="controle-formulario" value="<?php echo e($origem); ?>" placeholder="Qualquer">
            </div>
            <div class="col-md-4">
                <label class="rotulo-formulario" for="destino"><i class="fas fa-location-dot me-2"></i>Destino</label>
                <input type="text" id="destino" name="destino" class="controle-formulario" value="<?php echo e($destino); ?>" placeholder="Qualquer">
            </div>
            <div class="col-md-4">
                <label class="rotulo-formulario" for="data"><i class="fas fa-calendar me-2"></i>Data</label>
                <input type="date" id="data" name="data" class="controle-formulario" value="<?php echo e($data); ?>">
            </div>
            <div class="col-12 d-grid">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search me-2"></i>Buscar Carona</button>
            </div>
        </form>

        <h3 class="titulo-secao"><i class="fas fa-list-ul me-2"></i>Caronas Disponíveis</h3>

        <?php if (!$caronas): ?>
            <p class="text-muted">Nenhuma carona disponível no momento para os critérios informados.</p>
        <?php endif; ?>

        <?php foreach ($caronas as $c): ?>
            <?php
            $propria = (int) $c['motorista_id'] === $uid;
            $situacao = $minhas[(int) $c['id']] ?? null;
            ?>
            <div class="cartao-carona">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                    <div>
                        <div class="trecho"><?php echo e($c['origem']); ?> <i class="fas fa-arrow-right mx-1"></i> <?php echo e($c['destino']); ?></div>
                        <div class="detalhe">
                            <i class="fas fa-calendar me-1"></i><?php echo e(dataHoraBR($c['data_viagem'], $c['hora_viagem'])); ?>
                            · <i class="fas fa-user ms-1 me-1"></i><?php echo e($c['motorista_nome']); ?>
                            <?php if ((float) $c['motorista_avaliacao'] > 0): ?>
                                · <i class="fas fa-star text-warning ms-1"></i> <?php echo number_format((float) $c['motorista_avaliacao'], 1, ',', ''); ?>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($c['observacoes'])): ?>
                            <div class="detalhe mt-1"><i class="fas fa-comment-dots me-1"></i><?php echo e($c['observacoes']); ?></div>
                        <?php endif; ?>
                    </div>
                    <span class="badge bg-success"><?php echo (int) $c['vagas_livres']; ?> vaga(s)</span>
                </div>

                <div class="mt-2">
                    <?php if ($propria): ?>
                        <span class="text-muted small">Esta carona é sua.</span>
                    <?php elseif ($situacao === 'pendente' || $situacao === 'aceita' || $situacao === 'recusada'): ?>
                        <span class="small">Sua solicitação: <?php echo badgeStatus($situacao); ?></span>
                    <?php else: ?>
                        <form method="POST" class="d-inline">
                            <?php echo csrfCampo(); ?>
                            <input type="hidden" name="carona_id" value="<?php echo (int) $c['id']; ?>">
                            <input type="hidden" name="origem" value="<?php echo e($origem); ?>">
                            <input type="hidden" name="destino" value="<?php echo e($destino); ?>">
                            <input type="hidden" name="data" value="<?php echo e($data); ?>">
                            <button type="submit" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-hand-paper me-1"></i>Solicitar vaga
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
