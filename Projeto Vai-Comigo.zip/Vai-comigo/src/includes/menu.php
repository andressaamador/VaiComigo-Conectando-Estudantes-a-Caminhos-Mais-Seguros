<?php
require_once __DIR__ . '/../Classes/Notificacao.php';
$naoLidas = isLoggedIn() ? Notificacao::contarNaoLidas(getIdUsuario()) : 0;
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="home.php">
            <i class="fas fa-car-side"></i>
            VaiComigo
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('home.php'); ?>" href="home.php">
                        <i class="fas fa-home"></i> Início
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('cadastro.php'); ?>" href="cadastro.php">
                        <i class="fas fa-plus-circle"></i> Oferecer Carona
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('busca.php'); ?>" href="busca.php">
                        <i class="fas fa-search"></i> Buscar Carona
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('minhas-caronas.php'); ?>" href="minhas-caronas.php">
                        <i class="fas fa-car"></i> Minhas Caronas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('chat.php'); ?>" href="chat.php">
                        <i class="fas fa-comments"></i> Chat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('avaliacoes.php'); ?>" href="avaliacoes.php">
                        <i class="fas fa-star"></i> Avaliações
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('notificacoes.php'); ?>" href="notificacoes.php">
                        <i class="fas fa-bell"></i> Notificações
                        <?php if ($naoLidas > 0): ?>
                            <span class="badge bg-danger"><?php echo (int) $naoLidas; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo isActive('perfil.php'); ?>" href="perfil.php">
                        <i class="fas fa-user-circle"></i> Perfil
                    </a>
                </li>
                <?php if (isAdmin()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="gestor.php">
                        <i class="fas fa-user-shield"></i> Gestão
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> Sair
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<main>
<?php foreach (flashMensagens() as $msg): ?>
    <div class="container mt-3">
        <div class="alert alert-<?php echo e($msg['tipo']); ?> alert-dismissible fade show" role="alert">
            <?php echo e($msg['texto']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
        </div>
    </div>
<?php endforeach; ?>
