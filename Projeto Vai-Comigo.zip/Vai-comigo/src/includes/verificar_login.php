<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Verifica se o usuário está logado
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['usuario_logado']) && !empty($_SESSION['usuario_logado']);
}

/**
 * Obtém os dados do usuário logado
 * @return array|null
 */
function getUsuarioLogado() {
    return $_SESSION['usuario_logado'] ?? null;
}

/**
 * Obtém o ID do usuário logado
 * @return int
 */
function getIdUsuario() {
    $usuario = getUsuarioLogado();
    return (int) ($usuario['id'] ?? 0);
}

/**
 * Obtém o nome do usuário logado
 * @return string
 */
function getNomeUsuario() {
    $usuario = getUsuarioLogado();
    return $usuario['nome'] ?? 'Usuário';
}

/**
 * Obtém o tipo do usuário logado
 * @return string
 */
function getTipoUsuario() {
    $usuario = getUsuarioLogado();
    return $usuario['tipo_usuario'] ?? 'aluno';
}

/**
 * Obtém a foto do usuário logado
 * @return string|null
 */
function getFotoUsuario() {
    $usuario = getUsuarioLogado();
    return $usuario['foto_perfil'] ?? null;
}

/**
 * Verifica se o usuário é admin
 * @return bool
 */
function isAdmin() {
    return getTipoUsuario() === 'admin';
}

/**
 * Redireciona para login se não estiver logado
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Redireciona para a página inicial se não for admin
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: home.php');
        exit;
    }
}

/**
 * Escapa texto para saída em HTML
 * @param mixed $valor
 * @return string
 */
function e($valor) {
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

/**
 * Token CSRF da sessão (gerado uma única vez por sessão)
 * @return string
 */
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Campo hidden com o token CSRF para formulários POST
 * @return string
 */
function csrfCampo() {
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

/**
 * Valida o token CSRF enviado no POST; encerra a requisição se inválido
 */
function csrfValidar() {
    $enviado = $_POST['csrf_token'] ?? '';
    if (!is_string($enviado) || !hash_equals(csrfToken(), $enviado)) {
        http_response_code(400);
        exit('Requisição inválida. Recarregue a página e tente novamente.');
    }
}

/**
 * Guarda uma mensagem para exibir na próxima página (padrão PRG)
 * @param string $tipo success|danger|warning|info
 * @param string $texto
 */
function flash($tipo, $texto) {
    $_SESSION['flash'][] = ['tipo' => $tipo, 'texto' => $texto];
}

/**
 * Retorna e limpa as mensagens pendentes
 * @return array
 */
function flashMensagens() {
    $msgs = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $msgs;
}

/**
 * Faz logout do usuário
 */
function logout() {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Bloqueia páginas internas para quem não está logado
$current_page = basename($_SERVER['PHP_SELF']);
$public_pages = ['login.php', 'index.php'];

if (!in_array($current_page, $public_pages) && !isLoggedIn()) {
    header('Location: login.php');
    exit;
}
