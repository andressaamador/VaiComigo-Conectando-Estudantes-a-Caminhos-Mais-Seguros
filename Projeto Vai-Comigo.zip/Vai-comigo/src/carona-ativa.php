<?php
// Página antiga ("Carona Ativa"), substituída por "Minhas Caronas".
header('Location: minhas-caronas.php', true, 301);
exit;
