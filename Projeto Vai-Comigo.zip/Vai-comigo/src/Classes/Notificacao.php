<?php

require_once __DIR__ . "/BD.php";

/**
 * Notificações destinadas aos usuários (RF12).
 * Tipos aceitos pela tabela: solicitacao, aceite, recusa, cancelamento, mensagem, sistema.
 */
class Notificacao {

    const TIPOS = ['solicitacao', 'aceite', 'recusa', 'cancelamento', 'mensagem', 'sistema'];

    /**
     * Registra uma notificação. Usa a mesma conexão (singleton) das demais classes,
     * portanto participa da transação em andamento, se houver.
     */
    public static function criar($usuarioId, $tipo, $titulo, $mensagem) {
        if (!in_array($tipo, self::TIPOS, true)) {
            throw new InvalidArgumentException("Tipo de notificação inválido: $tipo");
        }
        $conn = BD::getConnection();
        $st = $conn->prepare("INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo) VALUES (?, ?, ?, ?)");
        $st->execute([(int) $usuarioId, $titulo, $mensagem, $tipo]);
        return (int) $conn->lastInsertId();
    }

    public static function listarPorUsuario($usuarioId) {
        $st = BD::getConnection()->prepare(
            "SELECT * FROM notificacoes WHERE usuario_id = ? ORDER BY data_criacao DESC, id DESC"
        );
        $st->execute([(int) $usuarioId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function contarNaoLidas($usuarioId) {
        $st = BD::getConnection()->prepare("SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND lida = 0");
        $st->execute([(int) $usuarioId]);
        return (int) $st->fetchColumn();
    }

    public static function marcarComoLida($id, $usuarioId) {
        $st = BD::getConnection()->prepare("UPDATE notificacoes SET lida = 1 WHERE id = ? AND usuario_id = ?");
        $st->execute([(int) $id, (int) $usuarioId]);
        return $st->rowCount() > 0;
    }

    public static function marcarTodasComoLidas($usuarioId) {
        $st = BD::getConnection()->prepare("UPDATE notificacoes SET lida = 1 WHERE usuario_id = ? AND lida = 0");
        $st->execute([(int) $usuarioId]);
        return $st->rowCount();
    }

    public static function limpar($usuarioId) {
        $st = BD::getConnection()->prepare("DELETE FROM notificacoes WHERE usuario_id = ?");
        $st->execute([(int) $usuarioId]);
        return $st->rowCount();
    }
}
