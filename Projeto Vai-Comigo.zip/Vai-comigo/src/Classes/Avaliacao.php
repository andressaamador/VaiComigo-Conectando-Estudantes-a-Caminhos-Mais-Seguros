<?php

require_once __DIR__ . "/BD.php";
require_once __DIR__ . "/Notificacao.php";
require_once __DIR__ . "/Mensagem.php";

/**
 * Avaliações entre participantes (RF11).
 * RN07: somente após a finalização da carona, entre participantes da mesma viagem
 * e uma única vez por avaliador/avaliado/carona.
 * O campo usuarios.avaliacao (média) é um dado derivado, recalculado na mesma transação.
 */
class Avaliacao {

    public static function avaliar($caronaId, $avaliadorId, $avaliadoId, $nota, $comentario = null) {
        $caronaId = (int) $caronaId;
        $avaliadorId = (int) $avaliadorId;
        $avaliadoId = (int) $avaliadoId;

        if (filter_var($nota, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]) === false) {
            throw new Exception('A nota deve ser um número inteiro de 1 a 5.');
        }
        if ($avaliadorId === $avaliadoId) {
            throw new Exception('Não é possível avaliar a si mesmo.');
        }
        $comentario = trim((string) $comentario);
        $comentario = $comentario === '' ? null : mb_substr($comentario, 0, 1000);

        $conn = BD::getConnection();
        $conn->beginTransaction();
        try {
            $st = $conn->prepare("SELECT status FROM caronas WHERE id = ? FOR UPDATE");
            $st->execute([$caronaId]);
            $status = $st->fetchColumn();
            if ($status === false) {
                throw new Exception('Carona não encontrada.');
            }
            if ($status !== 'finalizada') {
                throw new Exception('A avaliação só é permitida após a finalização da carona.'); // RN07
            }

            $participantes = Mensagem::participantes($caronaId);
            if (!in_array($avaliadorId, $participantes, true) || !in_array($avaliadoId, $participantes, true)) {
                throw new Exception('Somente participantes da mesma carona podem se avaliar.'); // RN07
            }

            try {
                $st = $conn->prepare("INSERT INTO avaliacoes (avaliador_id, avaliado_id, carona_id, nota, comentario) VALUES (?, ?, ?, ?, ?)");
                $st->execute([$avaliadorId, $avaliadoId, $caronaId, (int) $nota, $comentario]);
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') { // violação da UNIQUE (avaliador, avaliado, carona)
                    throw new Exception('Você já avaliou este participante nesta carona.');
                }
                throw $e;
            }
            $id = (int) $conn->lastInsertId();

            // Atualiza o dado derivado (média) na mesma transação, evitando divergência
            $st = $conn->prepare("UPDATE usuarios SET avaliacao = (SELECT ROUND(AVG(nota), 2) FROM avaliacoes WHERE avaliado_id = ?) WHERE id = ?");
            $st->execute([$avaliadoId, $avaliadoId]);

            Notificacao::criar($avaliadoId, 'sistema', 'Nova avaliação', 'Você recebeu uma avaliação referente a uma carona finalizada.');

            $conn->commit();
            return $id;
        } catch (Throwable $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Participantes que o usuário ainda pode avaliar em caronas finalizadas.
     */
    public static function pendentes($usuarioId) {
        $u = (int) $usuarioId;
        $st = BD::getConnection()->prepare("
            SELECT c.id AS carona_id, c.origem, c.destino, c.data_viagem, c.hora_viagem,
                   s.passageiro_id AS avaliado_id, u.nome AS avaliado_nome, 'passageiro' AS papel
            FROM caronas c
            INNER JOIN solicitacoes_carona s ON s.carona_id = c.id AND s.status = 'aceita'
            INNER JOIN usuarios u ON u.id = s.passageiro_id
            WHERE c.status = 'finalizada' AND c.motorista_id = ?
              AND NOT EXISTS (SELECT 1 FROM avaliacoes a
                              WHERE a.avaliador_id = ? AND a.avaliado_id = s.passageiro_id AND a.carona_id = c.id)
            UNION ALL
            SELECT c.id, c.origem, c.destino, c.data_viagem, c.hora_viagem,
                   c.motorista_id, u.nome, 'motorista'
            FROM caronas c
            INNER JOIN solicitacoes_carona s ON s.carona_id = c.id AND s.status = 'aceita' AND s.passageiro_id = ?
            INNER JOIN usuarios u ON u.id = c.motorista_id
            WHERE c.status = 'finalizada'
              AND NOT EXISTS (SELECT 1 FROM avaliacoes a
                              WHERE a.avaliador_id = ? AND a.avaliado_id = c.motorista_id AND a.carona_id = c.id)
            ORDER BY data_viagem DESC
        ");
        $st->execute([$u, $u, $u, $u]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function recebidas($usuarioId) {
        $st = BD::getConnection()->prepare("
            SELECT a.*, u.nome AS avaliador_nome, c.origem, c.destino, c.data_viagem
            FROM avaliacoes a
            INNER JOIN usuarios u ON u.id = a.avaliador_id
            INNER JOIN caronas c ON c.id = a.carona_id
            WHERE a.avaliado_id = ?
            ORDER BY a.data_avaliacao DESC
        ");
        $st->execute([(int) $usuarioId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function enviadas($usuarioId) {
        $st = BD::getConnection()->prepare("
            SELECT a.*, u.nome AS avaliado_nome, c.origem, c.destino, c.data_viagem
            FROM avaliacoes a
            INNER JOIN usuarios u ON u.id = a.avaliado_id
            INNER JOIN caronas c ON c.id = a.carona_id
            WHERE a.avaliador_id = ?
            ORDER BY a.data_avaliacao DESC
        ");
        $st->execute([(int) $usuarioId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
