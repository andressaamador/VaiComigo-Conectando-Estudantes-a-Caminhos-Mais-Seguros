<?php

require_once __DIR__ . "/BD.php";
require_once __DIR__ . "/Notificacao.php";

/**
 * Solicitações de vaga em caronas (RF06, RF07, RF08).
 *
 * Todas as operações que alteram a situação de uma solicitação rodam em transação
 * (InnoDB) e bloqueiam primeiro a linha da carona com SELECT ... FOR UPDATE e depois
 * a da solicitação. A ordem fixa de bloqueio (carona -> solicitação) evita deadlocks e
 * garante que duas aceitações simultâneas não ultrapassem a capacidade da carona (RN05).
 */
class Solicitacao {

    /**
     * Executa $fn dentro de uma transação, desfazendo tudo em caso de erro.
     */
    private static function transacao(callable $fn) {
        $conn = BD::getConnection();
        $conn->beginTransaction();
        try {
            $resultado = $fn($conn);
            $conn->commit();
            return $resultado;
        } catch (Throwable $e) {
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            throw $e;
        }
    }

    private static function bloquearCarona(PDO $conn, $caronaId) {
        $st = $conn->prepare("SELECT * FROM caronas WHERE id = ? FOR UPDATE");
        $st->execute([(int) $caronaId]);
        $carona = $st->fetch(PDO::FETCH_ASSOC);
        if (!$carona) {
            throw new Exception('Carona não encontrada.');
        }
        return $carona;
    }

    private static function bloquearSolicitacao(PDO $conn, $solicitacaoId) {
        // Lê sem bloqueio apenas para descobrir a carona; o bloqueio segue a ordem carona -> solicitação
        $st = $conn->prepare("SELECT carona_id FROM solicitacoes_carona WHERE id = ?");
        $st->execute([(int) $solicitacaoId]);
        $caronaId = $st->fetchColumn();
        if ($caronaId === false) {
            throw new Exception('Solicitação não encontrada.');
        }
        $carona = self::bloquearCarona($conn, $caronaId);

        $st = $conn->prepare("SELECT * FROM solicitacoes_carona WHERE id = ? FOR UPDATE");
        $st->execute([(int) $solicitacaoId]);
        $solicitacao = $st->fetch(PDO::FETCH_ASSOC);
        return [$carona, $solicitacao];
    }

    private static function nomeUsuario(PDO $conn, $usuarioId) {
        $st = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $st->execute([(int) $usuarioId]);
        return (string) $st->fetchColumn();
    }

    /**
     * Passageiro solicita vaga (RF06). Regras: RN02, RN03, RN04.
     * @return int ID da solicitação
     */
    public static function solicitar($caronaId, $passageiroId) {
        $passageiroId = (int) $passageiroId;
        return self::transacao(function (PDO $conn) use ($caronaId, $passageiroId) {
            $carona = self::bloquearCarona($conn, $caronaId);

            if ((int) $carona['motorista_id'] === $passageiroId) {
                throw new Exception('Você não pode solicitar vaga na sua própria carona.'); // RN02
            }
            if ($carona['status'] !== 'ativa' || (int) $carona['vagas_ocupadas'] >= (int) $carona['vagas_disponiveis']) {
                throw new Exception('Esta carona não está disponível para novas solicitações.'); // RN03
            }

            $st = $conn->prepare("SELECT id, status FROM solicitacoes_carona WHERE carona_id = ? AND passageiro_id = ? FOR UPDATE");
            $st->execute([(int) $caronaId, $passageiroId]);
            $existente = $st->fetch(PDO::FETCH_ASSOC);

            if ($existente) {
                // RN04: uma única solicitação por carona (garantida também pela UNIQUE do banco)
                if ($existente['status'] === 'pendente' || $existente['status'] === 'aceita') {
                    throw new Exception('Você já possui uma solicitação para esta carona.');
                }
                if ($existente['status'] === 'recusada') {
                    throw new Exception('Sua solicitação para esta carona foi recusada pelo motorista.');
                }
                // Solicitação cancelada pelo próprio passageiro pode ser reaberta
                $st = $conn->prepare("UPDATE solicitacoes_carona SET status = 'pendente', data_solicitacao = NOW() WHERE id = ?");
                $st->execute([(int) $existente['id']]);
                $id = (int) $existente['id'];
            } else {
                $st = $conn->prepare("INSERT INTO solicitacoes_carona (carona_id, passageiro_id) VALUES (?, ?)");
                $st->execute([(int) $caronaId, $passageiroId]);
                $id = (int) $conn->lastInsertId();
            }

            Notificacao::criar(
                $carona['motorista_id'],
                'solicitacao',
                'Nova solicitação de carona',
                self::nomeUsuario($conn, $passageiroId) . ' solicitou uma vaga na sua carona para ' . $carona['destino'] . '.'
            );
            return $id;
        });
    }

    /**
     * Motorista aceita a solicitação (RF07). Transação com bloqueio da carona (RN05).
     */
    public static function aceitar($solicitacaoId, $motoristaId) {
        return self::transacao(function (PDO $conn) use ($solicitacaoId, $motoristaId) {
            [$carona, $sol] = self::bloquearSolicitacao($conn, $solicitacaoId);

            if ((int) $carona['motorista_id'] !== (int) $motoristaId) {
                throw new Exception('Apenas o motorista da carona pode responder às solicitações.');
            }
            if ($sol['status'] !== 'pendente') {
                throw new Exception('Esta solicitação não está mais pendente.');
            }
            if ($carona['status'] !== 'ativa') {
                throw new Exception('A carona não está ativa.');
            }
            if ((int) $carona['vagas_ocupadas'] >= (int) $carona['vagas_disponiveis']) {
                // ROLLBACK: a solicitação permanece pendente
                throw new Exception('Não há vagas disponíveis nesta carona.');
            }

            $conn->prepare("UPDATE solicitacoes_carona SET status = 'aceita' WHERE id = ?")->execute([(int) $sol['id']]);
            $conn->prepare("UPDATE caronas SET vagas_ocupadas = vagas_ocupadas + 1 WHERE id = ?")->execute([(int) $carona['id']]);

            Notificacao::criar(
                $sol['passageiro_id'],
                'aceite',
                'Solicitação aceita',
                'Sua solicitação para a carona ' . $carona['origem'] . ' → ' . $carona['destino'] . ' foi aceita.'
            );
            return true;
        });
    }

    /**
     * Motorista recusa a solicitação pendente (RF07).
     */
    public static function recusar($solicitacaoId, $motoristaId) {
        return self::transacao(function (PDO $conn) use ($solicitacaoId, $motoristaId) {
            [$carona, $sol] = self::bloquearSolicitacao($conn, $solicitacaoId);

            if ((int) $carona['motorista_id'] !== (int) $motoristaId) {
                throw new Exception('Apenas o motorista da carona pode responder às solicitações.');
            }
            if ($sol['status'] !== 'pendente') {
                throw new Exception('Esta solicitação não está mais pendente.');
            }

            $conn->prepare("UPDATE solicitacoes_carona SET status = 'recusada' WHERE id = ?")->execute([(int) $sol['id']]);

            Notificacao::criar(
                $sol['passageiro_id'],
                'recusa',
                'Solicitação recusada',
                'Sua solicitação para a carona ' . $carona['origem'] . ' → ' . $carona['destino'] . ' foi recusada.'
            );
            return true;
        });
    }

    /**
     * Passageiro cancela a própria solicitação (RF08). Se já estava aceita, a vaga é liberada.
     */
    public static function cancelar($solicitacaoId, $passageiroId) {
        return self::transacao(function (PDO $conn) use ($solicitacaoId, $passageiroId) {
            [$carona, $sol] = self::bloquearSolicitacao($conn, $solicitacaoId);

            if ((int) $sol['passageiro_id'] !== (int) $passageiroId) {
                throw new Exception('Você só pode cancelar as suas próprias solicitações.');
            }
            if ($sol['status'] !== 'pendente' && $sol['status'] !== 'aceita') {
                throw new Exception('Esta solicitação não pode mais ser cancelada.');
            }
            if ($carona['status'] !== 'ativa') {
                throw new Exception('A carona já foi encerrada.');
            }

            if ($sol['status'] === 'aceita') {
                $conn->prepare("UPDATE caronas SET vagas_ocupadas = GREATEST(vagas_ocupadas - 1, 0) WHERE id = ?")
                     ->execute([(int) $carona['id']]);
            }
            $conn->prepare("UPDATE solicitacoes_carona SET status = 'cancelada' WHERE id = ?")->execute([(int) $sol['id']]);

            Notificacao::criar(
                $carona['motorista_id'],
                'cancelamento',
                'Solicitação cancelada',
                self::nomeUsuario($conn, $passageiroId) . ' cancelou a solicitação na sua carona para ' . $carona['destino'] . '.'
            );
            return true;
        });
    }

    /**
     * Solicitações recebidas em uma carona, com dados de contato do passageiro.
     */
    public static function listarPorCarona($caronaId) {
        $st = BD::getConnection()->prepare("
            SELECT s.*, u.nome AS passageiro_nome, u.email AS passageiro_email, u.telefone AS passageiro_telefone
            FROM solicitacoes_carona s
            INNER JOIN usuarios u ON u.id = s.passageiro_id
            WHERE s.carona_id = ?
            ORDER BY s.data_solicitacao
        ");
        $st->execute([(int) $caronaId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Solicitações feitas por um passageiro, com os dados da carona e do motorista.
     */
    public static function listarPorPassageiro($passageiroId) {
        $st = BD::getConnection()->prepare("
            SELECT s.id, s.status, s.data_solicitacao, s.carona_id,
                   c.origem, c.destino, c.data_viagem, c.hora_viagem, c.status AS carona_status,
                   u.nome AS motorista_nome, u.email AS motorista_email, u.telefone AS motorista_telefone
            FROM solicitacoes_carona s
            INNER JOIN caronas c ON c.id = s.carona_id
            INNER JOIN usuarios u ON u.id = c.motorista_id
            WHERE s.passageiro_id = ?
            ORDER BY c.data_viagem DESC, c.hora_viagem DESC
        ");
        $st->execute([(int) $passageiroId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
