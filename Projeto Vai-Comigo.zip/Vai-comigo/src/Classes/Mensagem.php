<?php

require_once __DIR__ . "/BD.php";
require_once __DIR__ . "/Notificacao.php";

/**
 * Chat vinculado a cada carona (RF10).
 * RN06: apenas o motorista e os passageiros com solicitação aceita acessam a conversa.
 */
class Mensagem {

    const TAMANHO_MAXIMO = 1000;

    /**
     * Verifica se o usuário participa da carona (motorista ou passageiro aceito).
     */
    public static function podeAcessar($caronaId, $usuarioId) {
        $st = BD::getConnection()->prepare("
            SELECT 1 FROM caronas c
            WHERE c.id = ?
              AND (c.motorista_id = ?
                   OR EXISTS (SELECT 1 FROM solicitacoes_carona s
                              WHERE s.carona_id = c.id AND s.passageiro_id = ? AND s.status = 'aceita'))
        ");
        $st->execute([(int) $caronaId, (int) $usuarioId, (int) $usuarioId]);
        return (bool) $st->fetchColumn();
    }

    /**
     * IDs dos participantes da carona (motorista + passageiros aceitos).
     */
    public static function participantes($caronaId) {
        $st = BD::getConnection()->prepare("
            SELECT motorista_id AS id FROM caronas WHERE id = ?
            UNION
            SELECT passageiro_id FROM solicitacoes_carona WHERE carona_id = ? AND status = 'aceita'
        ");
        $st->execute([(int) $caronaId, (int) $caronaId]);
        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }

    public static function enviar($caronaId, $usuarioId, $texto) {
        if (!self::podeAcessar($caronaId, $usuarioId)) {
            throw new Exception('Você não participa desta carona.'); // RN06
        }
        $texto = trim((string) $texto);
        if ($texto === '') {
            throw new Exception('A mensagem não pode ser vazia.');
        }
        if (mb_strlen($texto) > self::TAMANHO_MAXIMO) {
            throw new Exception('A mensagem deve ter no máximo ' . self::TAMANHO_MAXIMO . ' caracteres.');
        }

        $conn = BD::getConnection();
        $st = $conn->prepare("INSERT INTO mensagens (carona_id, usuario_id, mensagem) VALUES (?, ?, ?)");
        $st->execute([(int) $caronaId, (int) $usuarioId, $texto]);
        $id = (int) $conn->lastInsertId();

        $nome = $conn->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $nome->execute([(int) $usuarioId]);
        $remetente = (string) $nome->fetchColumn();

        foreach (self::participantes($caronaId) as $destinatario) {
            if ($destinatario !== (int) $usuarioId) {
                Notificacao::criar($destinatario, 'mensagem', 'Nova mensagem', $remetente . ' enviou uma mensagem no chat da carona.');
            }
        }
        return $id;
    }

    public static function listar($caronaId, $usuarioId) {
        if (!self::podeAcessar($caronaId, $usuarioId)) {
            throw new Exception('Você não participa desta carona.'); // RN06
        }
        $st = BD::getConnection()->prepare("
            SELECT m.*, u.nome AS remetente_nome
            FROM mensagens m
            INNER JOIN usuarios u ON u.id = m.usuario_id
            WHERE m.carona_id = ?
            ORDER BY m.data_envio, m.id
        ");
        $st->execute([(int) $caronaId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Caronas em que o usuário participa e que, portanto, possuem conversa disponível.
     */
    public static function conversasDoUsuario($usuarioId) {
        $st = BD::getConnection()->prepare("
            SELECT c.id, c.origem, c.destino, c.data_viagem, c.hora_viagem, c.status, u.nome AS motorista_nome,
                   (SELECT COUNT(*) FROM mensagens m WHERE m.carona_id = c.id) AS total_mensagens
            FROM caronas c
            INNER JOIN usuarios u ON u.id = c.motorista_id
            WHERE c.motorista_id = ?
               OR c.id IN (SELECT s.carona_id FROM solicitacoes_carona s WHERE s.passageiro_id = ? AND s.status = 'aceita')
            ORDER BY c.data_viagem DESC, c.hora_viagem DESC
        ");
        $st->execute([(int) $usuarioId, (int) $usuarioId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
}
