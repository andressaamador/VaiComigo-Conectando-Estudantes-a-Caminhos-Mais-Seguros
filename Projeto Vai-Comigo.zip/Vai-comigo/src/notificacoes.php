<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Notificacao.php';

$uid = getIdUsuario();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    switch ($_POST['acao'] ?? '') {
        case 'marcar':
            Notificacao::marcarComoLida((int) ($_POST['id'] ?? 0), $uid);
            break;
        case 'marcar_todas':
            Notificacao::marcarTodasComoLidas($uid);
            break;
        case 'limpar':
            Notificacao::limpar($uid);
            flash('info', 'Notificações removidas.');
            break;
    }
    header('Location: notificacoes.php');
    exit;
}

$notificacoes = Notificacao::listarPorUsuario($uid);

$icones = [
    'solicitacao'  => 'fa-car-side text-primary',
    'aceite'       => 'fa-check-circle text-success',
    'recusa'       => 'fa-times-circle text-danger',
    'cancelamento' => 'fa-ban text-secondary',
    'mensagem'     => 'fa-comments text-primary',
    'sistema'      => 'fa-info-circle text-info',
];

$page_title = 'Notificações';
$page_css = 'notificacoes.css';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container mt-4">
    <div class="container-notificacoes">
        <h2 class="mb-4"><i class="fas fa-bell text-primary"></i> Notificações</h2>

        <div class="lista-notificacoes">
            <?php if (!$notificacoes): ?>
                <p class="text-muted">Você não tem notificações.</p>
            <?php endif; ?>
            <?php foreach ($notificacoes as $n): ?>
                <div class="notificacao <?php echo $n['lida'] ? '' : 'nao-lida'; ?>">
                    <div class="icone-notificacao">
                        <i class="fas <?php echo e($icones[$n['tipo']] ?? 'fa-bell text-primary'); ?>"></i>
                    </div>
                    <div class="conteudo-notificacao">
                        <h5><?php echo e($n['titulo']); ?></h5>
                        <p><?php echo e($n['mensagem']); ?></p>
                        <small class="texto-tempo"><?php echo e(date('d/m/Y H:i', strtotime($n['data_criacao']))); ?></small>
                    </div>
                    <?php if (!$n['lida']): ?>
                        <form method="POST">
                            <?php echo csrfCampo(); ?>
                            <input type="hidden" name="acao" value="marcar">
                            <input type="hidden" name="id" value="<?php echo (int) $n['id']; ?>">
                            <button type="submit" class="btn-marcar-lida" title="Marcar como lida"><i class="fas fa-check"></i></button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($notificacoes): ?>
            <div class="acoes-notificacao mt-4 d-flex gap-2 flex-wrap">
                <form method="POST">
                    <?php echo csrfCampo(); ?>
                    <input type="hidden" name="acao" value="marcar_todas">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-check-double me-2"></i>Marcar todas como lidas</button>
                </form>
                <form method="POST" onsubmit="return confirm('Remover todas as notificações?');">
                    <?php echo csrfCampo(); ?>
                    <input type="hidden" name="acao" value="limpar">
                    <button type="submit" class="btn btn-outline-danger"><i class="fas fa-trash-alt me-2"></i>Limpar notificações</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
