<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Carona.php';

$dados = ['origem' => '', 'destino' => '', 'data_viagem' => '', 'hora_viagem' => '', 'vagas_disponiveis' => 3, 'observacoes' => ''];
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    foreach ($dados as $campo => $padrao) {
        $dados[$campo] = trim((string) ($_POST[$campo] ?? ''));
    }
    try {
        if ($dados['origem'] === '' || $dados['destino'] === '') {
            throw new Exception('Informe o local de partida e o destino.');
        }
        if (mb_strlen($dados['origem']) > 255 || mb_strlen($dados['destino']) > 255) {
            throw new Exception('Origem e destino devem ter no máximo 255 caracteres.');
        }
        $data = DateTime::createFromFormat('Y-m-d', $dados['data_viagem']);
        if (!$data || $data->format('Y-m-d') !== $dados['data_viagem']) {
            throw new Exception('Informe uma data válida.');
        }
        if (!preg_match('/^\d{2}:\d{2}$/', $dados['hora_viagem'])) {
            throw new Exception('Informe um horário válido.');
        }
        if ($dados['data_viagem'] === date('Y-m-d') && $dados['hora_viagem'] < date('H:i')) {
            throw new Exception('O horário da carona já passou.');
        }
        $vagas = filter_var($dados['vagas_disponiveis'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 4]]);
        if ($vagas === false) {
            throw new Exception('A quantidade de vagas deve estar entre 1 e 4.');
        }

        $carona = new Carona();
        $carona->inserir(
            getIdUsuario(),
            $dados['origem'],
            $dados['destino'],
            $dados['data_viagem'],
            $dados['hora_viagem'],
            $vagas,
            $dados['observacoes'] !== '' ? $dados['observacoes'] : null
        );
        flash('success', 'Carona cadastrada! Acompanhe as solicitações em Minhas Caronas.');
        header('Location: minhas-caronas.php');
        exit;
    } catch (Exception $e) {
        $erro = $e->getMessage();
    }
}

$page_title = 'Oferecer Carona';
$page_css = 'cadastro.css';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="painel" style="max-width: 640px;">
        <h2 class="text-center mb-4">Oferecer Carona</h2>

        <?php if ($erro): ?>
            <div class="alert alert-danger"><?php echo e($erro); ?></div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <?php echo csrfCampo(); ?>
            <label class="rotulo-formulario" for="origem">
                <i class="fas fa-map-marker-alt me-2"></i>Local de partida
            </label>
            <input type="text" id="origem" name="origem" class="controle-formulario" maxlength="255"
                   placeholder="Ex.: IFTO Campus Colinas" value="<?php echo e($dados['origem']); ?>" required>

            <label class="rotulo-formulario" for="destino">
                <i class="fas fa-location-dot me-2"></i>Destino
            </label>
            <input type="text" id="destino" name="destino" class="controle-formulario" maxlength="255"
                   placeholder="Ex.: Centro" value="<?php echo e($dados['destino']); ?>" required>

            <div class="row">
                <div class="col-sm-6">
                    <label class="rotulo-formulario" for="data_viagem">
                        <i class="fas fa-calendar me-2"></i>Data
                    </label>
                    <input type="date" id="data_viagem" name="data_viagem" class="controle-formulario"
                           min="<?php echo date('Y-m-d'); ?>" value="<?php echo e($dados['data_viagem']); ?>" required>
                </div>
                <div class="col-sm-6">
                    <label class="rotulo-formulario" for="hora_viagem">
                        <i class="fas fa-clock me-2"></i>Horário
                    </label>
                    <input type="time" id="hora_viagem" name="hora_viagem" class="controle-formulario"
                           value="<?php echo e($dados['hora_viagem']); ?>" required>
                </div>
            </div>

            <label class="rotulo-formulario" for="vagas_disponiveis">
                <i class="fas fa-users me-2"></i>Vagas disponíveis
            </label>
            <input type="number" id="vagas_disponiveis" name="vagas_disponiveis" class="controle-formulario"
                   min="1" max="4" value="<?php echo e($dados['vagas_disponiveis']); ?>" required>

            <label class="rotulo-formulario" for="observacoes">
                <i class="fas fa-comment-dots me-2"></i>Observações (opcional)
            </label>
            <textarea id="observacoes" name="observacoes" class="controle-formulario" rows="3" maxlength="1000"
                      placeholder="Ponto de encontro, paradas, etc."><?php echo e($dados['observacoes']); ?></textarea>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i>Cadastrar
                </button>
                <a href="home.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times-circle me-2"></i>Cancelar
                </a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
