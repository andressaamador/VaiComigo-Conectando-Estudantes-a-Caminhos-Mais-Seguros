<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/verificar_login.php';
require_once __DIR__ . '/Classes/Mensagem.php';

$uid = getIdUsuario();
$caronaId = (int) ($_GET['carona'] ?? $_POST['carona_id'] ?? 0);

// Enviar mensagem (RF10)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidar();
    try {
        Mensagem::enviar($caronaId, $uid, $_POST['mensagem'] ?? '');
    } catch (Exception $e) {
        flash('danger', $e->getMessage());
    }
    header('Location: chat.php?carona=' . $caronaId . '#fim');
    exit;
}

$conversas = Mensagem::conversasDoUsuario($uid);
$mensagens = [];
$atual = null;
$erro = '';

if ($caronaId > 0) {
    foreach ($conversas as $c) {
        if ((int) $c['id'] === $caronaId) {
            $atual = $c;
        }
    }
    try {
        $mensagens = Mensagem::listar($caronaId, $uid); // RN06: bloqueia quem não participa
    } catch (Exception $e) {
        $erro = $e->getMessage();
        $atual = null;
    }
}

$page_title = 'Chat';
include __DIR__ . '/includes/header.php';
?>
<body>
<?php include __DIR__ . '/includes/menu.php'; ?>

<div class="container">
    <div class="painel" style="max-width: 1100px;">
        <div class="row g-4">
            <div class="col-lg-4">
                <h3 class="titulo-secao mt-0"><i class="fas fa-comments me-2"></i>Conversas</h3>
                <?php if (!$conversas): ?>
                    <p class="text-muted small">As conversas aparecem quando você oferece uma carona ou tem uma solicitação aceita.</p>
                <?php endif; ?>
                <div class="list-group">
                    <?php foreach ($conversas as $c): ?>
                        <a href="chat.php?carona=<?php echo (int) $c['id']; ?>"
                           class="list-group-item list-group-item-action <?php echo (int) $c['id'] === $caronaId ? 'active' : ''; ?>">
                            <div class="fw-semibold"><?php echo e($c['origem']); ?> → <?php echo e($c['destino']); ?></div>
                            <small><?php echo e(dataHoraBR($c['data_viagem'], $c['hora_viagem'])); ?> · <?php echo e($c['motorista_nome']); ?></small>
                            <div><?php echo badgeStatus($c['status']); ?> <small><?php echo (int) $c['total_mensagens']; ?> mensagem(ns)</small></div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-lg-8">
                <?php if ($erro): ?>
                    <div class="alert alert-warning"><?php echo e($erro); ?></div>
                <?php elseif (!$atual): ?>
                    <p class="text-muted mt-4 text-center">Selecione uma conversa para visualizar as mensagens.</p>
                <?php else: ?>
                    <h3 class="titulo-secao mt-0"><?php echo e($atual['origem']); ?> → <?php echo e($atual['destino']); ?></h3>
                    <div class="chat-mensagens mb-3">
                        <?php if (!$mensagens): ?>
                            <p class="text-muted text-center">Ainda não há mensagens nesta conversa.</p>
                        <?php endif; ?>
                        <?php foreach ($mensagens as $m): ?>
                            <?php $minha = (int) $m['usuario_id'] === $uid; ?>
                            <div class="balao <?php echo $minha ? 'minha' : ''; ?>">
                                <div class="meta"><?php echo e($minha ? 'Você' : $m['remetente_nome']); ?> · <?php echo e(date('d/m H:i', strtotime($m['data_envio']))); ?></div>
                                <div><?php echo nl2br(e($m['mensagem'])); ?></div>
                            </div>
                        <?php endforeach; ?>
                        <span id="fim"></span>
                    </div>
                    <form method="POST" class="d-flex gap-2">
                        <?php echo csrfCampo(); ?>
                        <input type="hidden" name="carona_id" value="<?php echo (int) $caronaId; ?>">
                        <input type="text" name="mensagem" class="form-control" maxlength="1000" placeholder="Digite sua mensagem..." required autofocus>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    // Mantém a conversa rolada até a última mensagem
    document.querySelectorAll('.chat-mensagens').forEach(function (el) { el.scrollTop = el.scrollHeight; });
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
