# VaiComigo

Plataforma web de caronas compartilhadas entre estudantes do IFTO – Campus Colinas do Tocantins
(TCC de Análise e Desenvolvimento de Sistemas). A documentação do TCC e os diagramas estão em
[`docs/tcc/`](docs/tcc/).

## Como executar

Requisitos: Docker e Docker Compose.

```bash
docker compose up -d --build
```

| Serviço     | Endereço              |
|-------------|-----------------------|
| Aplicação   | http://localhost:8080 |
| phpMyAdmin  | http://localhost:8081 (servidor `db`, usuário `root`, senha `root`) |

O banco é criado a partir de `src/database/init.sql` na **primeira** subida do contêiner. Para recriá-lo
do zero (por exemplo, antes de executar o plano de testes):

```bash
docker compose down -v && docker compose up -d --build
```

## Acesso

O VaiComigo **não possui cadastro próprio**: o login usa a mesma matrícula e senha dos sistemas
acadêmicos da instituição. No protótipo, a base institucional é representada pela tabela `usuarios`,
carregada com as contas abaixo.

| Perfil | Matrícula | Senha |
|---|---|---|
| Administrador | `ADM001` | `admin123` |
| Estudante (motorista) | `20260001` | `vaicomigo123` |
| Estudante (passageiro) | `20260002` | `vaicomigo123` |
| Estudante (passageira) | `20260003` | `vaicomigo123` |
| Estudante inativo (acesso bloqueado) | `20260004` | `vaicomigo123` |
| Estudante | `202322170019` | `2215` |

## Funcionalidades

- Login com matrícula e senha institucionais; bloqueio de contas inativas; sessão com proteção contra fixação.
- Oferta de carona, busca por origem/destino/data (filtragem relacional – MVP).
- Solicitação de vaga, aceite/recusa pelo motorista e cancelamento pelo passageiro.
- **Aceite transacional** (`SELECT … FOR UPDATE` + `COMMIT`/`ROLLBACK`): duas aceitações simultâneas não excedem a capacidade.
- Minhas Caronas (oferecidas e solicitadas), finalização e cancelamento pelo motorista.
- Chat por carona restrito aos participantes; avaliações (1 a 5) após a finalização, com média recalculada.
- Notificações de solicitação, aceite, recusa, cancelamento, mensagem e avaliação.
- Painel administrativo restrito ao perfil administrador; proteção CSRF em todos os formulários.

Regras de negócio implementadas (RN01–RN08 do TCC): `src/Classes/Solicitacao.php`, `Mensagem.php`,
`Avaliacao.php` e `Carona.php`.

## Plano de testes (Seção 4.6 do TCC)

Com os contêineres em execução:

```bash
docker compose exec php php tests/executar_testes.php
```

O roteiro executa os casos **TF01–TF12** e **TI01–TI08** contra o banco real, usando dados próprios
(matrículas `TST…`) que são removidos ao final. O registro de cada execução — data, dados de entrada,
resultado obtido e situação, no formato do modelo de registro do TCC — é salvo em
`src/tests/resultados/execucao-AAAAMMDD-HHMMSS.md`.

TI01 e TI02 fazem requisições HTTP ao próprio servidor (`http://localhost/` dentro do contêiner).
Para outro endereço: `docker compose exec -e VAICOMIGO_URL=http://localhost/ php php tests/executar_testes.php`.
